# ProyectoFinalLucio
 Este es un enorme compendio de todas las clases de PPV2.

Como descargar:

Acceda al repositorio y apriete el boton <CODE>, y descargue el ZIP.
Localize el ZIP, y descomprima el archivo.
Migre la carpeta a Unity, y abra el proyecto ahi.

En la escena, se encontraran dos escenas. Una es para la seleccion de nivel, la otra para el juego en si.

![image](https://github.com/PokiOfTheBoki/ProyectoFinalLucio/assets/156141663/78b74776-5264-4e31-b568-7399ac64d8b8)



Para jugar el juego, observe la pregunta, y dele click a la respuesta que crea sea correcta. Compruebe su respuesta, y asi hasta acabar.

![image](https://github.com/PokiOfTheBoki/ProyectoFinalLucio/assets/156141663/28e4a4ce-ad4b-47e6-aa09-bd19c99d3903)
